#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "symtab.h"

SymbolTableEntryPtr symbolTable = NULL;

int symbolTableLookup(SymbolTableName name, SymbolTableEntryPtrPtr value){
 return SYMTAB_OK;
}
