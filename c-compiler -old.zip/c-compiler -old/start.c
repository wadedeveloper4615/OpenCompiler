#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include "global.h"
#include "c.y.h"
#include "c.l.h"

int num_errors;

size_t min(size_t a, size_t b) {
    return b < a ? b : a;
}

size_t getline(char **lineptr, size_t *n, FILE *stream) {
    char *bufptr = NULL;
    char *p = bufptr;
    size_t size;
    int c;

    if (lineptr == NULL) {
        return -1;
    }
    if (stream == NULL) {
        return -1;
    }
    if (n == NULL) {
        return -1;
    }
    bufptr = *lineptr;
    size = *n;

    c = fgetc(stream);
    if (c == EOF) {
        return -1;
    }
    if (bufptr == NULL) {
        bufptr = malloc(128);
        if (bufptr == NULL) {
            return -1;
        }
        size = 128;
    }
    p = bufptr;
    while(c != EOF) {
        if ((p - bufptr) > (size - 1)) {
            size = size + 128;
            bufptr = realloc(bufptr, size);
            if (bufptr == NULL) {
                return -1;
            }
        }
        *p++ = c;
        if (c == '\n') {
            break;
        }
        c = fgetc(stream);
    }

    *p++ = '\0';
    *lineptr = bufptr;
    *n = size;

    return p - bufptr - 1;
}

int initializeLexicalAnalysis(char * fileInput) {
 int error; 
 yyin = fopen(fileInput, "r");

 if(yyin == NULL)
  error = EXIT_FAILURE;
 else { 
  error = EXIT_SUCCESS;
 }
 return error;
}

int endLexicalAnalysis() {
 int error; 
   
 error = fclose(yyin);
 if (error == 0) { 
  error = fclose(fileLexLog);
  if (error == 0)
   error = EXIT_SUCCESS;
  else
   error = EXIT_FAILURE;
 }
 else
  error = EXIT_FAILURE;
 return error; 
}

int initializeSyntacticAnalysis(char * fileOutput) {
 int error; 
   
 yyout = fopen(fileOutput, "w");

 num_errors = 0; 
 if (yyout == NULL) { 
  error = EXIT_FAILURE; 
 } else { 
  error = EXIT_SUCCESS; 
 }
 return error;
}

int symanticAnalysis() {
 int error;
   
 if (yyparse() == 0){
  error =  EXIT_SUCCESS;
 } else {
  error =  EXIT_FAILURE;
 }
 return error;
}


int endSyntacticAnalysis() {
 int error;
   
 error = fclose(yyout);
   
 if (num_errors > 0) {
  fprintf(stdout, "\n\n\t-----------------------------------------------------");
  fprintf(stdout, "\n\t\t[ ERR ] Compiled with %d error/s\n", num_errors);
  fprintf(stdout, "\t-----------------------------------------------------\n\n");
 }
 else {
  fprintf(stdout, "\n\n\t-----------------------------------------------------");
  fprintf(stdout, "\n\t\t[ OK ] Compilation generated successfully\n"); 
  fprintf(stdout, "\t-----------------------------------------------------\n\n");
 }
 if (error == 0){
  error = EXIT_SUCCESS; 
 } else { 
  error = EXIT_FAILURE;
 }
 return error; 
}

int main(int argc, char *argv[]) {
 if (argc == 3) {
  if (initializeLexicalAnalysis(argv[1]) == EXIT_SUCCESS) {
   if (initializeSyntacticAnalysis(argv[2]) == EXIT_SUCCESS) {
    symanticAnalysis();
    endLexicalAnalysis(); 
    endSyntacticAnalysis();
   } else {
    printf("\n\n###########################################################\n");
    printf("###\t\t\t\t\t\t\t###\n");
    printf("###\t[ ERR ] El fitxers de sortida %s no s'han creat\t###\n", argv[2]);
    printf("###\t\t\t\t\t\t\t###\n");      
    printf("###########################################################\n\n");       
   }
  } else {
   printf("\n\n###########################################################\n");
   printf("###\t\t\t\t\t\t\t###\n");
   printf("###\t[ ERR ] El fitxer d'entrada %s no existeix\t###\n", argv[1]);
   printf("###\t\t\t\t\t\t\t###\n");      
   printf("###########################################################\n\n");       
  }
 } else {
  printf("\n\n###########################################################################\n");
  printf("###\t\t\t\t\t\t\t\t\t###\n");
  printf("###\t[ USE ] %s [ F_IN ] [ F_OUT ]      \t\t\t###\n", argv[0]);
  printf("###\t[ EX  ] %s input.txt output.txt\t\t\t###\n", argv[0]);
  printf("###\t\t\t\t\t\t\t\t\t###\n");      
  printf("###########################################################################\n\n");
 }
}
