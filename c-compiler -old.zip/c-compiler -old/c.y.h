extern int yyparse();
extern FILE* yyin;
extern FILE * yyout;
extern int lineNumber;
extern int yyleng;
extern char yytext[];
extern int column;
extern int yylineno;

void yyerror(const char * explanation);

size_t min(size_t a, size_t b);
size_t getline(char **lineptr, size_t *n, FILE *stream);
