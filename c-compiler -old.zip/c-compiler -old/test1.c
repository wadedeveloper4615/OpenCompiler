unsigned int var1;

int main(){
 return 0;
}