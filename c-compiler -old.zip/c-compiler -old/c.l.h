extern FILE * yyin;
extern FILE * fileLexLog;

int yywrap();
int yylex();
void comment();
int handleIndentifier();
void yyerror(const char * explanation);

size_t min(size_t a, size_t b);
size_t getline(char **lineptr, size_t *n, FILE *stream);
